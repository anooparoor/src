//Anoop Aroor
/*Module Name: Relative support weight learning
Objective: refer documentation
Author: Anoop Aroor
Date : 09-20-2013
Files : main.cpp, rswl.cpp and rswl.h */

#include <iostream>
#include <algorithm>
#include <list>
#include <string>
#include <map>

using namespace std;

const int advisorCount = 5;
const int actionTypeCount = 9;
const int intensityCount = 5;
const int actionCount = actionTypeCount * intensityCount;
const int robotCount = 1;
const float initialWeight = 0.05;
const float closenessThreshold = 30;

class Location
{
public:
  int xCoordinate;
  int yCoordinate; 
};


class RobotDecision
{
public:
  int decisionId;
  float distanceFromTarget;	
  Location robotLocation;
  //int robotOrientation;
  Location targetLocation;
  int robotId;
  //map<string, string> infoUsed;
  float advisorComments[advisorCount][actionCount];
  float advisorPreference[advisorCount][actionCount];
  int actionChoice;
  int tier;
  bool goalState;	
};

class Digression
{
public:
  RobotDecision start;
  RobotDecision end;
};


class RSWL
{	
	public: int learnWeights();
	int printPathList(list< list<RobotDecision> >);
	int printDecisionList(list<RobotDecision>);
	int printDecision(RobotDecision);
	list< list<RobotDecision> > computeDistanceFromTarget(list< list<RobotDecision> >);

        list<Digression> removeDuplicateDigression(list<Digression>);
	list<RobotDecision> parseLog();
	RobotDecision insertDetail(string, string, RobotDecision);
	list< list<RobotDecision> > extractSuccessfulPaths(list<RobotDecision>);
	float* computeWeights(list< list<RobotDecision> >);
	Digression findDigression(list<RobotDecision>);
        list<Digression> extractDigression(list<RobotDecision>);	
	int addPenalty(Digression,float[],float[]);
	list<RobotDecision> removeDigression(list<RobotDecision>, list<Digression>);
	RobotDecision findInPath(list<RobotDecision>, int);
	int addReward(float[], RobotDecision, float[]);
	float* computeRelativeSupport(float[][actionCount], int);
	bool checkEqual(RobotDecision, RobotDecision);
	bool isAdvisorInvolved(int, float[][actionCount]);
	float getAverage(float []);
	float getDistance(Location, Location);
	float* distinct(float[],int);
	float* sort(float[]);
	RobotDecision computeAdvisorPreference(RobotDecision);
};

