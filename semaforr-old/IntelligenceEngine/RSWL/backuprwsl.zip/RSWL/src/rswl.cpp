//Anoop Aroor
/*Module Name: Relative support weight learning
Objective: refer documentation
Author: Anoop Aroor
Date : 09-20-2013
Files : RSWL.cpp and RSWL.h */

#include <iostream>
#include <list>
#include <string>
#include <map>
#include <cmath>
#include <algorithm>
#include <fstream>
#include <regex>
#include "rswl.h"

using namespace std;
        // The main function which reads logs file , computes weights and prints them. It uses all other functions in this class.
	int RSWL::learnWeights()
	{
		cout << "parselog() start\n";		
		list<RobotDecision> rawDecision = parseLog();
		cout << "printDecisionList() start\n";
		//printDecisionList(rawDecision);		
		list< list<RobotDecision> > successfulPathList = extractSuccessfulPaths(rawDecision);
		successfulPathList = computeDistanceFromTarget(successfulPathList);
		cout << "extractSuccessfulPaths() start \n ";
		printPathList(successfulPathList);
		cout << "computeWeights() start \n";
		float *weights;
		weights = computeWeights(successfulPathList);
		int i;		
		cout << "Weights: \n";
		for(i = 0 ; i < advisorCount; i ++)
		{
			cout << "Advisor " << i+1 << " : " << weights[i] << endl;
		}				
		//writeIntoConfigFile(weights);
		return 0;
	}

	//given a list of paths, where each path is a list of robotdecision which took the robot from its starting point
        //to its target, this function computes at every decision point, the distance from that point to the target point
        //along the path.
	list< list<RobotDecision> > RSWL::computeDistanceFromTarget(list< list<RobotDecision> > pathList)
	{
                //for every path in the list
		list< list<RobotDecision> >::iterator pathiterator;
		list<RobotDecision>::reverse_iterator decisioniterator;
		for(pathiterator = pathList.begin(); pathiterator != pathList.end(); pathiterator++)
		{
                        //traverse the path in the reverse direction from the target to the orginal position
			RobotDecision previous;
			for(decisioniterator = (*pathiterator).rbegin(); decisioniterator != (*pathiterator).rend(); decisioniterator++)
			{
                                //when the decision is the final decision , decision from target = 0
				if(decisioniterator == (*pathiterator).rbegin())	
				{
					(*decisioniterator).distanceFromTarget = 0;	
				}
                                // otherwise distance from target = distance from this position to the previous position + distance to
                                // target of the previous decision 
				else
				{
					(*decisioniterator).distanceFromTarget = previous.distanceFromTarget + getDistance((*decisioniterator).robotLocation, previous.robotLocation);
					//cout << "previous to target :" << previous.distanceFromTarget << endl;
					//cout << " distance to previous :" << getDistance((*decisioniterator).robotLocation, previous.robotLocation) << endl;
				}
				//cout << (*decisioniterator).distanceFromTarget << endl;
				//cout << "current decision id : " << (*decisioniterator).decisionId <<endl;
				//cout << "previous decision id : " << previous.decisionId << endl;
				previous = (*decisioniterator);
			}
		}
		return pathList;
	}


        // Prints the given list of paths
	int RSWL::printPathList(list< list<RobotDecision> > pathList)
	{	
		list< list<RobotDecision> >::iterator pathiterator;
		for(pathiterator = pathList.begin(); pathiterator != pathList.end(); pathiterator++)
		{
			cout << "new path==========================================================\n";
			printDecisionList(*pathiterator);
		}
		return 0;
	}


        // Prints a given list of decision or a single path
	int RSWL::printDecisionList(list<RobotDecision> decisionList)
	{	
		list<RobotDecision>::iterator decisioniterator;
		for(decisioniterator = decisionList.begin(); decisioniterator != decisionList.end(); decisioniterator++)
		{
			printDecision(*decisioniterator);
		}
		return 0;
	}


        // Prints a single decision and the details
	int RSWL::printDecision(RobotDecision decision)
	{
		cout << "new decision ---> " << endl;
		cout << "Robot ID - " << decision.robotId <<endl;		
		cout << "Decision ID - " << decision.decisionId <<endl;
		cout << "Decision Tier - " << decision.tier << endl;
		cout << "Goal state - " << decision.goalState <<endl;
		cout << "Action chosen - " << decision.actionChoice <<endl;
		cout << "Target (x,y)- (" << decision.targetLocation.xCoordinate <<","<< decision.targetLocation.yCoordinate << ")"<< endl;
		cout << "Robot Location (x,y) - (" <<decision.robotLocation.xCoordinate<<","<<decision.robotLocation.yCoordinate<< ")" << endl;
		cout << "Distance from target - " << decision.distanceFromTarget << endl;
		/*int i,j;		
		for(i = 0 ; i < advisorCount; i++)
		{
			cout << "Advisor " << to_string(i+1) << " comments are:" <<endl;
			for(j = 0; j<actionCount; j++)
			{
				cout << "   Action " << j+1 << " comment strength is - " << to_string(decision.advisorComments[i][j]) <<endl;
				//cout<<"   Action " <<j+1<< " preference strength is - " <<to_string(decision.advisorPreference[i][j]) <<endl;
			}
		}*/
		return 0;
	}


        // This is the function which reads the log files and stores the data as Objects of RobotDecision class
	list<RobotDecision> RSWL::parseLog()
	{
		list<RobotDecision> rawDecision; 
                // Each robot controller is expected to have a seperate log file which documents its decisions and movements
                // robot1.log : is the log file of robot numbered 1, and so on.
   		for(int i = 1;i <= robotCount; i++)
		{		
			string line;
			string filename = "robot";
			filename.append(to_string(i));
			filename.append(".log");
			ifstream myfile(filename);
                        // Open the file, read every line and fill in the object of the class RobotDecision
  			if(myfile.is_open())
  			{
				//cout << "opening new file: " << filename << "\n";
				RobotDecision decision;
    				while(getline(myfile,line))
    				{
					line.erase(remove(line.begin(), line.end(),' '), line.end());
					transform(line.begin(),line.end(), line.begin(), ::tolower);
		//			cout << line << "\n";
					//every decision in the log has a ID number and also the current goal that it is pursuing. 
                                        //decisions are written using xml like tags, with <decision> indicating a new decision , and 
                                        //</decision> indicating end of information related to the decision.
					if(line == "<decision>")
					{
						//reinitialize decision
						RobotDecision newDecision;
						decision = newDecision;
						continue;	
					}
					else if(line == "</decision>")
					{ 
				//		cout << "decision inserted into the rawDecision list \n";
						//printDecision(decision);
                                                // Every time a new decision object is created, to normalize the comment strenghts from 
                                                // differnt advisors we use computeAdvisorPreference function
						decision = computeAdvisorPreference(decision);
						//printDecision(decision);
      						rawDecision.push_back(decision);					
					}
                                        // insertdetail() function is called to insert a specific information about the decision into 
                                        // the corresponding fields of the RobotDecision object
					else
					{
                                                //every informaiton is the log is written as a name value pair , separated by :
						unsigned delimPos = line.find(":");
						string name = line.substr(0,delimPos);
						string value = line.substr(delimPos + 1);	
				//		cout << "calling function insertDetail()\n";
				//		cout << "	with name = " << name << endl;
				//		cout << "	with value = " << value << endl;
						decision = insertDetail(name, value, decision);
					}
    				}
    				myfile.close();
  			}
		}
		cout << "end of parselog"  << endl;
		return rawDecision;	
	}
	

	// Advisors comment on different actions avaliable to the robot, this function uses the comment strength values 
        // to create a ranking of the actions according to each advisors preference. So for every advisor we generate a rank for
        // actions , with higher rank indicating a stronger preference.
	RobotDecision RSWL::computeAdvisorPreference(RobotDecision decision)
	{
		cout << "start compute advisor preference function" << endl;
		for(int i = 0; i< advisorCount; i++)
		{
                        //advisorComment is a matrix of [advisors] and [actions] , with each cell containing the comment strength
                        // if a dvisor chooses not to comment on any of the actions then cell will contain "1000"
			if(decision.advisorComments[i][0] == 1000)
			{	
				for(int j = 0; j < actionCount;j++)
				{
					decision.advisorPreference[i][j] = decision.advisorComments[i][j];
				}	
			}
                        // if the advisor does comment, assign a ranking to the advisorPreference based on the comments in the
                        // advisorComment matrix
			else
			{
				//sort the comments
                                float* unsortedComments = decision.advisorComments[i];
				float* comments = new float[actionCount];
				for(int l = 0; l < actionCount ; l ++)
				{
					comments[l] = unsortedComments[l];
				}
			        float* sortedComments = sort(comments);
				// count the number of distinct comments
				int count = actionCount;
				for(int x = 0; x < (actionCount - 1); x++)
				{ 
					if(sortedComments[x] == sortedComments[x+1])
					{
						count = count - 1;
					}
				}
                                // remove duplicates from the comments 
				float* distinctSortedComments = distinct(sortedComments,count);
                                // start with the lowest value comment and every comment which matches this comment is given a rank of 1
				for(int j = 0; j < count; j++)
				{
					float comment = distinctSortedComments[j];
					for(int k = 0; k < actionCount; k++)
					{
						if(unsortedComments[k] == comment)
						{
							decision.advisorPreference[i][k] = j + 1;
						}
					}
				}
			}
		}		
		return decision;
	}

        // sort the comments in the ascending order
	float* RSWL::sort(float comments[])
	{
		for(int i = 0; i < actionCount; i++)
		{
			for(int j = i+1; j < actionCount; j++)
			{			
				if(comments[i] > comments[j])
				{
					float temp = comments[i];
					comments[i] = comments[j]; 
					comments[j] = temp;
				}
			}
			//cout << comments[i] << endl;
		}
		return comments;
	}


        // accepts a sorted array and return a sorted array without duplicates
	float* RSWL::distinct(float sortedComments[], int count)
	{
		float* distinctSortedComments = new float[count];
		int m,n = 0;
		for(m = 0; m < actionCount; m++)
		{ 
			if(m == 0)
			{
				distinctSortedComments[n] = sortedComments[m];
				n = n + 1;
			}
			else
			{
				if(sortedComments[m] != distinctSortedComments[n-1])
				{
					distinctSortedComments[n] = sortedComments[m];
					n = n + 1;
				}				
			}		
		}	
		return distinctSortedComments;
	}


        // this function is used by the parse log, to identify the type of the detail and insert into the 
        // RobotDecision object accordingly
	RobotDecision RSWL::insertDetail(string name, string value, RobotDecision decision)
	{	
		regex rx ("(<)(.*)");
		if(name == "robotid")
			decision.robotId = 1 ; 
		else if(name == "decisionid")
			decision.decisionId = stoi(value) + 1;//because the log starts with decision 0;
		else if(name == "targetx")
			decision.targetLocation.xCoordinate = stoi(value);		
		else if(name == "targety")
			decision.targetLocation.yCoordinate = stoi(value);		
		else if(name == "tier")
			decision.tier = stoi(value);
		else if(name == "goalstate")
		{		
			if(value == "true")
				decision.goalState = true;		
			else
				decision.goalState = false;		
		}		
		else if(name == "actionchosen")
		{
			int actionTypeId = stoi(value.substr((value.find("<") +1),(value.find(",") -1)));
			int intensityId = stoi(value.substr((value.find(",") +1),(value.find(">") -1)));	
			decision.actionChoice = (actionTypeId * intensityCount) + intensityId;
		}		
		else if(name == "robotlocationx")
			decision.robotLocation.xCoordinate = stoi(value);
		else if(name == "robotlocationy")
			decision.robotLocation.yCoordinate = stoi(value);
		else if(regex_match (name,rx))
		{
			string advisorName = name.substr((name.find("<") + 1),(name.find(",") -1));
			int actionTypeId = stoi(name.substr((name.find(",") +1),(name.find_last_of(",") -1)));
			int intensityId = stoi(name.substr((name.find_last_of(",") +1),(name.find(">") -1)));
			//cout << "action type id :" << actionTypeId<< endl;
			//cout << "intensity id :" << intensityId<< endl;
			int actionId = (actionTypeId * intensityCount) + intensityId;
			int advisorId;
			if(advisorName == "greedyadvisor")
				advisorId = 1;			
			else if(advisorName == "obstacleavoidadvisor")
				advisorId = 2;
			else if(advisorName == "bigstepadvisor")
				advisorId = 3;
			else if(advisorName == "closeinadvisor")
				advisorId = 4;			
			else if(advisorName == "notoppositeadvisor")
				advisorId = 5;
			else
			{
				//cout << "Error in indentifying advisors" << endl;
			}
			if(value == "inactive")
			{
				int j = 0;
				//cout << advisorId << endl;
				for(j = 0; j < actionCount; j++)
				{
					decision.advisorComments[advisorId - 1][j] = 1000;
					//cout << advisorId << j+1 << " " << decision.advisorComments[advisorId-1][j] <<endl;
				}
			}
			else
			{
				decision.advisorComments[advisorId - 1][actionId - 1] = stof(value);
				//cout << advisorId << actionId << " " << decision.advisorComments[advisorId-1][actionId-1] <<endl;
			}			
		}
		// remove after getting the right log
		decision.tier = 3;
		decision.robotId = 1;
		return decision;	
	}
 

        // Once the raw decision list is created and advisorPreference ranks are generated , this function splits a single list 
        // into a list of list of decisions or a list of paths, with each path indicating a robot meeting a particular objective 
	list< list<RobotDecision> > RSWL::extractSuccessfulPaths(list<RobotDecision> rawDecisions)
	{ 
		list< list<RobotDecision> > successfulPathList;
		list<RobotDecision>::iterator decisioniterator;
		list<RobotDecision> robotArray[robotCount];
                // add every decision into a new path until the decision has goal state = true, and then add the path into the path list.
		for(decisioniterator = rawDecisions.begin(); decisioniterator != rawDecisions.end(); decisioniterator++)
		{	
			RobotDecision decision = *decisioniterator; 
			//cout << "tier: "<< decision.decisionId << endl;
			if(decision.tier == 3)
			{
				robotArray[(decision.robotId)-1].push_back(decision);
				if(decision.goalState == true)
				{
					list<RobotDecision> path = robotArray[(decision.robotId)-1]; 		
					robotArray[(decision.robotId)-1].clear();
					//printDecisionList(path);
					successfulPathList.push_back(path);
				}
			}
		}
		return successfulPathList;
	}			
						
        // returns a list with weights of the advisors
	float* RSWL::computeWeights(list< list<RobotDecision> > pathList)
	{
		//------------- Declare and initialize weights and comment count---
		float* weights = new float[advisorCount];
		float* commentCount = new float[advisorCount];
		for(int k = 0; k < advisorCount; k++)
		{
			commentCount[k] = 0;
			weights[k] = initialWeight;
		}		

		// ------------ For each path in path list --------------------
		list< list<RobotDecision> >::iterator pathiterator;	
		for(pathiterator = pathList.begin(); pathiterator != pathList.end(); pathiterator++)
		{
			list<RobotDecision> path = *pathiterator;
			path.pop_back();
			//--------------- Extraction digressions ------------------
			list<Digression> totalDigression = extractDigression(path);
			
			//--------------- Add penalty for every digression -------
			list<Digression>::iterator digressioniterator;			
			for(digressioniterator = totalDigression.begin(); digressioniterator != totalDigression.end(); digressioniterator++)
			{
				cout << "calling penalty function for decisionId :" << (*digressioniterator).start.decisionId << endl; 					addPenalty((*digressioniterator),weights,commentCount);
				cout << "Weights after adding penalty: \n";
				for(int i = 0 ; i < advisorCount; i ++)
				{
					cout << "Advisor " << i+1 << " : " << weights[i] << endl;
				}
			}
			
			//-------------- Remove Digression to get positive decision list ----
			list<RobotDecision> positiveDecisionList = path;
			if(totalDigression.size() >= 1)
			{
	//			cout << "calling remove digression" << endl;
				positiveDecisionList = removeDigression(path,totalDigression);
			}
			list<RobotDecision>::iterator decisioniterator1;
			cout << "Positive decision list:   ---------" << endl;
			//printDecisionList(positiveDecisionList);
			cout << "End of positive Decision list :  ------- "<< endl;

			//-------------- Add reward for every positive decision --------------
			for(decisioniterator1 = positiveDecisionList.begin(); decisioniterator1 != positiveDecisionList.end(); decisioniterator1++)
			{
				RobotDecision decision = *decisioniterator1;
				cout << "calling reward function for decisionId :" << decision.decisionId << endl;
				addReward(weights,decision,commentCount);
				cout << "Weights ADDING REWARD: \n";
				for(int i = 0 ; i < advisorCount; i ++)
				{
					cout << "Advisor " << i+1 << " : " << weights[i] << endl;
				}
			}
		}
		// --------------- compute final weights by dividing p-weight by total comment count---------
		for(int k = 0; k < advisorCount; k++)
		{
			cout << "comment count of advisor " << k+1 << " : " << commentCount[k] << endl;
			if(commentCount[k] != 0)
			{
				weights[k] = weights[k]/commentCount[k];
			}
		}
		return weights;
	}	

        // Finds and returns digressions in a given path
	list<Digression> RSWL::extractDigression(list<RobotDecision> path)	
	{
		list<Digression> totalDigression;
		list<RobotDecision> coveredPath; 
		list<RobotDecision>::iterator decisioniterator;
                // for every decision in the path
		for(decisioniterator = path.begin(); decisioniterator != path.end(); decisioniterator++)
		{
			RobotDecision decision = *decisioniterator;
			coveredPath.push_back(decision);
			if(coveredPath.size() > 1)
			{
				//cout << "Calling function findDigression" << endl;
                                // check if the decision is same as the other previous decisions already covered by calling the 
                                // function findDigression()
				Digression digression = findDigression(coveredPath);
				if(digression.start.decisionId != 0 || digression.end.decisionId != 0)				
				{	
					totalDigression.push_front(digression);
                                        cout << "new digression found: "<< digression.start.decisionId <<" to " << digression.end.decisionId <<endl;
				}
			}		
		}
                // because we use an epsilon margin to check if two decisions are same, this leads to duplicate digressions
		totalDigression = removeDuplicateDigression(totalDigression);
		return totalDigression;
	}

        // this function removes the duplicate digressions created by the epsilon
        list<Digression> RSWL::removeDuplicateDigression(list<Digression> digressionList)
        {
                list<Digression> tempDigressionList; 
                list<Digression>::iterator digressioniterator;
                Digression current,previous;
                // for every digression
                for(digressioniterator = digressionList.begin(); digressioniterator != digressionList.end(); digressioniterator++)
		{
                       	if(digressioniterator == digressionList.begin())
		      	{ 
                       		previous = *digressioniterator;
                                tempDigressionList.push_back(previous);
                       	} 
                        else
                        {
                                current = *digressioniterator;
                                if(current.start.decisionId == previous.start.decisionId)
                                {
                        		tempDigressionList.pop_back();
                                }
                                tempDigressionList.push_back(current);
                                previous = current;
                        }
                }
                return tempDigressionList;
        }

        // returns a single digression 
	Digression RSWL::findDigression(list<RobotDecision> path)
	{
		Digression digression;
		digression.start.decisionId = 0;
		digression.end.decisionId = 0;
                // the last decision is the decision , with which all other earlier decisions will be tested to check for digression
		RobotDecision currentDecision = path.back();
		path.pop_back();
		list<RobotDecision>::reverse_iterator decisioniterator;
                // wasOutOfRange is used to make sure that there is atleast one decision point outside of the epsilon to get rid of some 
                // duplicate digressions created by introducing digressions
		bool wasOutOfRange = false;
		for(decisioniterator = path.rbegin(); decisioniterator != path.rend(); decisioniterator++)
		{
			RobotDecision decision = *decisioniterator;
			if(checkEqual(decision,currentDecision) == false)
			{
				wasOutOfRange = true;
			}
			if((checkEqual(decision,currentDecision) == true) && (wasOutOfRange == true))
			{
				digression.start = decision;
				digression.end = currentDecision;
				return digression; // important dont remove
			}
		}
		return digression;		 
	}


        // given a digression , this function computes the penalty using the decision which caused digression
	int RSWL::addPenalty(Digression digression,float* weights,float commentCount[])
	{
		// use the decision which caused the digression, i.e start of the digression
                RobotDecision wrongDecision = digression.start;
		cout << "negative decision:-------------- "<< endl;
		printDecision(wrongDecision);
		cout << "End:-------------- "<< endl;
                // compute relative support which tells how much a particular action is supported by each of the advisor which is interested
                // in the action.
		float* relativeSupport = computeRelativeSupport(wrongDecision.advisorPreference, wrongDecision.actionChoice);
		// because the action resulted in the bad decision , which lead to the digression, each advisor which supported a bad
                // decision is penalized
                for(int advisor = 1; advisor<= advisorCount; advisor++)
		{
			if(isAdvisorInvolved(advisor, wrongDecision.advisorPreference))
			{
				//commentCount[advisor-1] = commentCount[advisor-1] + 1;
		//		cout << "advisor " << advisor-1 << "is involved in decision " << wrongDecision.decisionId << endl;
                                // We consider an advisor supporting an action , if its relative support is > 0
				if(relativeSupport[advisor - 1] > 0)
				{	
					// p-weight = p-weight - RS/Difficulty(distance covered)
                                        weights[advisor - 1] = weights[advisor - 1] - (relativeSupport[advisor - 1] / 			                        wrongDecision.distanceFromTarget);
					commentCount[advisor-1] = commentCount[advisor-1] + 1;
				}
				else
				{
					//cout << "advisor does not support this decision" << endl;
				}		
			}
			else
			{	
		 		//cout << "advisor " << advisor << " is not involved in this decision" << endl;
			}
		}
		return 0;
	}
        

        // removes the digression from the path to leave behind only good or correct decisions which lead to the robot reaching the goal
	list<RobotDecision> RSWL::removeDigression(list<RobotDecision> path, list<Digression> totalDigression)
	{
		//cout << "before removing digression !!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		//printDecisionList(path);
		list<RobotDecision>::iterator decisioniterator;	
		list<Digression>::iterator digressioniterator;
                // for every digression
		for(digressioniterator = totalDigression.begin(); digressioniterator != totalDigression.end(); digressioniterator++)
		{
			Digression digression = *digressioniterator;
			list<RobotDecision> newPath;
		        // for every decision in the path
			for(decisioniterator = path.begin(); decisioniterator != path.end(); decisioniterator++)
			{
				RobotDecision decision =  *decisioniterator;
				//cout << "Decision id : " << decision.decisionId << endl;
				//cout << "Digre start : " << digression.startDecisionId << endl;		
				//cout << "Digre end : " << digression.endDecisionId << endl;
                                // if the decision is not a digression, save the decision in a new path
				if(decision.decisionId < digression.start.decisionId || decision.decisionId >= digression.end.decisionId) 
				{
					newPath.push_back(decision);
				}
			}
			path = newPath;
		}
		//cout << "after removing digression !!!!!!!!!!!!!!!!!!!!!!!!!!" << endl;
		//printDecisionList(path);
		return path;
	}



        // similar to add penalty , it adds penalty based on the relative support , and updates the comment count
	int RSWL::addReward(float* weights, RobotDecision decision, float commentCount[])
	{
		float* relativeSupport = computeRelativeSupport(decision.advisorPreference,decision.actionChoice);
		int advisor;		
		for(advisor = 1; advisor <= advisorCount; advisor ++)
		{	
			if(isAdvisorInvolved(advisor, decision.advisorPreference))
			{
				if(relativeSupport[advisor - 1] > 0)
				{
			//		cout << "relative support : " << relativeSupport[advisor - 1] << endl;
					weights[advisor - 1] = weights[advisor - 1] + relativeSupport[advisor - 1];
					commentCount[advisor-1] = commentCount[advisor-1] + 1;
				}
				else
				{
		//			cout << "Advisor " << advisor << " is not supporting the decision" << endl;	
				}
			}
			else
			{
		//		cout << "Advisor " << advisor << " is not involved in the decision making" << endl;
			}
		}
		return 0;
	}


        // computes relative support using the formula RS = commentstrength - avg of all of its comments
	float* RSWL::computeRelativeSupport(float advisorPreference[][actionCount], int action)
	{
		//cout << "action choosen :" << action << endl;
		float* relativeSupport = new float[advisorCount];
		for(int advisor = 1; advisor <= advisorCount; advisor++)
		{
			float *comments = advisorPreference[advisor-1];
		//	cout << "acion comment strength: " << comments[action - 1];
			float average = getAverage(comments);
		//	cout << "average comment strength: " << average << endl;
			relativeSupport[advisor - 1] = (comments[action - 1] - average)/average;
		//	cout << "relatve support" << relativeSupport[advisor - 1] << endl;
		}
		return relativeSupport;
	}


        // computes the average of an array..
	float RSWL::getAverage(float comments[])
	{
		float sum = 0;
		for(int i = 0; i < actionCount ; i++)
		{
		//	cout << comments[i] << endl;
			sum = sum + comments[i];
		}
		return (sum/actionCount);
	}	


        //Checks if the two decision states are same.. In this case robot state is just the robot location
	bool RSWL::checkEqual(RobotDecision decision, RobotDecision currentDecision)
	{
		//cout << " in function checkequal" << endl;
		if(getDistance(decision.robotLocation,currentDecision.robotLocation) < closenessThreshold)
		{
		//	cout << "two decision are equal" << endl;
			return true;
		}
		else
		{
		//	cout << "two decision are not equal" << endl;
			return false;
		}
	}


        // computes eucledian distance betweem two points
	float RSWL::getDistance(Location location1, Location location2)
	{
		float distance;
		distance = sqrt(pow(location1.xCoordinate-location2.xCoordinate,2) + pow(location1.yCoordinate-location2.yCoordinate,2));
		return distance;
	}

	// Checks if the advisor is involved in decision making or not
	bool RSWL::isAdvisorInvolved(int advisor, float advisorPreference[][actionCount] )
	{
		float* comments = advisorPreference[advisor-1];
		for(int i = 1; i <= actionCount ; i++)
		{
			//cout << "advisor Comment : " << comments[i-1] << endl;
			if(comments[i-1] == 1000)
			{
				return false;
			}
		}
		return true;
	}
